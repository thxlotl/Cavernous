
# CAVING ITEMS

Caving items adds cave related items to the game and is a branch of the Cavernous datapack.

## Acknowledgements & Dependencies

 - [Misodes Datapack Generators](https://misode.github.io/)
 - [WASD Unlock all recipes](https://wasdbuildteam.website/)

Created by thxlotl of Interstella Studios.

## 🔗 Links
Planet Minecraft Profile - https://www.planetminecraft.com/member/thxlotl/

Datapack Page - https://www.planetminecraft.com/data-pack/extra-caving-items/

Interstella Discord - https://discord.gg/D7hyC7AWMJ