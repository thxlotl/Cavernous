
# GEYSER BLOCK DATAPACK

The custom geyser block seamlessly adds a new block with many features tp
vanilla minecraft.

## Acknowledgements & Dependencies

 - [Misodes Datapack Generators](https://misode.github.io/)
 - [Block Util](https://github.com/ICY105/BlockUtils)
 - [Lantern Load](https://github.com/LanternMC/load)
 - [WASD Unlock all recipes](https://wasdbuildteam.website/)

Created by thxlotl of Interstella Studios.

## 🔗 Links
Planet Minecraft Profile - https://www.planetminecraft.com/member/thxlotl/

Datapack Page - https://www.planetminecraft.com/data-pack/geyser-block/

Interstella Discord - https://discord.gg/D7hyC7AWMJ