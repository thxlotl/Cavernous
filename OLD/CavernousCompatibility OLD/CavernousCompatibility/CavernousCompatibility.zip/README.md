
# CAVERNOUS COMPATIBILITY

Cavernous is a datapack that overhauls the caves in minecraft by adding a
multitude of different biomes and features. I hope you enjoy it and I hope
it adds to your mining and crafting experience!

## Acknowledgements & Dependencies

 - [Misodes Datapack Generators](https://misode.github.io/)

Created by thxlotl of Interstella Studios.

## 🔗 Links
Planet Minecraft Profile - https://www.planetminecraft.com/member/thxlotl/

Datapack Page - https://www.planetminecraft.com/data-pack/thxlotl-s-cave-biome-datapack/

Interstella Discord - https://discord.gg/D7hyC7AWMJ