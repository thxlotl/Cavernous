
# CAVERNOUS COMPATIBILITY

## Acknowledgements & Dependencies

 - [Misodes Datapack Generators](https://misode.github.io/)

Created by thxlotl of Interstella Studios.

## 🔗 Links
Planet Minecraft Profile - https://www.planetminecraft.com/member/thxlotl/

Datapack Page - https://www.planetminecraft.com/data-pack/thxlotl-s-cave-biome-datapack/

Interstella Discord - https://discord.gg/D7hyC7AWMJ